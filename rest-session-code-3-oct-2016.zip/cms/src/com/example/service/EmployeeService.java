/**
 * 
 */
package com.example.service;

import javax.validation.constraints.Min;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author mahesh_kp
 *
 */

@Path("employees")
public class EmployeeService {
	
	private Logger logger = LogManager.getLogger(this.getClass());
	
	@GET
	@Path("hello/{id}")
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHello(@PathParam("id") int id, @QueryParam("name") String name) {
		logger.debug("Entered in this class");
		logger.debug("Path Param = "+id);
		return "Hello from employee service "+"Name: "+name+" Emp No : "+id;
	}
	

}
