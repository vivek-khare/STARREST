package com.example.model;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;





public class EmployeeStore {

	private static EmployeeStore empStore;
	private static List<Employee> employees;
	private Logger logger = LogManager.getLogger(this.getClass());

	private EmployeeStore() {

	}

	public static EmployeeStore getInstance() {
		if (empStore == null) {
			empStore = new EmployeeStore();
		}

		return empStore;
	}
	
	public int getEmployeeCount(){
		if(employees == null){
			return 0;
		}else{
			return employees.size();
		}
	}

	public List<Employee> getAllEmployees(){
		return employees;
	}
	
	public boolean addEmployee(Employee employee) {
		if (employees == null) {
			logger.error("Employees is Null");
			return false;
		}
		employees.add(employee);
		return true;
	}
	
	public Employee findEmployeeByEmpNo(int employeeNumber) {
		logger.debug("Entered findEmployee method of singleton");
		Employee foundEmployee = null;
		if(employees == null){
			logger.debug("The employees collection is null");
			return null;
		}
		for(Employee emp:employees){
			if(emp.getEmpNo() == employeeNumber){
				logger.debug("found the emloyee");
				foundEmployee = emp;
				break;
			}
		}
		return foundEmployee;
	}
	
	public String deleteEmployee(int employeeNumber) {
		boolean empDeletedResult = false;
		Employee oldEmployee = null;
		for(Employee emp:employees){
			if(emp.getEmpNo() == employeeNumber){
				oldEmployee = emp;
				break;
			}
		}
		
		if(oldEmployee != null){
			employees.remove(oldEmployee);
			empDeletedResult = true;
			logger.debug("Employee Deleted");
		}
		if(empDeletedResult){
			return "Employee with Emp No:"+oldEmployee.getEmpNo()+" Deleted Successfully";
		}
		
		return "Employee with Emp No:"+oldEmployee.getEmpNo()+" Not Found";
	}
	
	public boolean updateEmployee(Employee updatedEmployee) {
		boolean empUpdateResult = false;
		Employee oldEmployee = null;
		for(Employee emp:employees){
			if(emp.getEmpNo() == updatedEmployee.getEmpNo()){
				oldEmployee = emp;
				break;
			}
		}
		
		if(oldEmployee != null){
			oldEmployee.setFirstName(updatedEmployee.getFirstName());
			oldEmployee.setLastName(updatedEmployee.getLastName());
			oldEmployee.setJoinDate(updatedEmployee.getJoinDate());
			oldEmployee.setLocation(updatedEmployee.getLocation());
			oldEmployee.setUnitName(updatedEmployee.getUnitName());
			oldEmployee.setYearsOfExperience(updatedEmployee.getYearsOfExperience());
			empUpdateResult = true;
		}
		return empUpdateResult;
	}

	public List<Employee> resetEmployeeList() {
		InputStream inputStream = this.getClass().getResourceAsStream("/employees.json");
		List<Employee> employeeList = new ArrayList<Employee>();
		try {
			Reader reader = new InputStreamReader(inputStream, "UTF-8");
			JsonReader jsonReader = Json.createReader(reader);
			JsonArray employeeArr = jsonReader.readArray();

			SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
			for (JsonValue jsonValue : employeeArr) {
				if (jsonValue.getValueType().equals(JsonValue.ValueType.OBJECT)) {
					JsonObject jsonObject = (JsonObject) jsonValue;
					Employee emp = new Employee();
					emp.setEmpNo(jsonObject.getJsonNumber("emp-no").intValue());
					emp.setFirstName(jsonObject.getString("first-name"));
					emp.setLastName(jsonObject.getString("last-name"));
					emp.setUnitName(jsonObject.getString("unit-name"));
					emp.setLocation(jsonObject.getString("location"));
					emp.setJoinDate(dateFormatter.parse(jsonObject.getString("join-date")));
					emp.setYearsOfExperience(jsonObject.getJsonNumber("years-of-experience").intValue());

					employeeList.add(emp);
				}
			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
		employees = employeeList;
		return employeeList;
	}

}
