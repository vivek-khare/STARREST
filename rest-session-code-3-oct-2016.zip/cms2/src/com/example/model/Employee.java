package com.example.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.example.adapter.DateAdapter;

//import com.google.gson.annotations.SerializedName;

@XmlRootElement
public class Employee {
	//@SerializedName("emp-number")
	@XmlElement(name = "emp-number")
	private int empNo;
	
	@XmlElement(name = "first-name")
	private String firstName;
	
	@XmlElement(name = "last-name")
	private String lastName;
	
	@XmlElement(name = "unit-name")
	private String unitName;
	
	@XmlElement(name = "join-date")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private Date joinDate;
	
	@XmlElement(name = "years-of-experience")
	private double yearsOfExperience;
	
	@XmlElement(name = "location")
	private String location;

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public double getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(double yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
