/**
 * 
 */
package com.example.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.example.model.Employee;
import com.example.model.EmployeeStore;
//import com.google.gson.Gson;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author mahesh_kp
 *
 */

@Path("employees")
@Api(value = "/employees", description = "Manage Employees")

public class EmployeeService {

	private Logger logger = LogManager.getLogger(this.getClass());

	@GET
	@Path("all")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "List all Employees", notes = "List all Employees in the organization", response = Employee.class, responseContainer = "List")

	public List<Employee> getAllEmployees() {

		// Gson gson = new Gson();

		return EmployeeStore.getInstance().getAllEmployees();
	}

	@GET
	@Path("all2")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllEmployees2() {
		return "Not yet implemented";

		/*
		 * Gson gson = new Gson();
		 * 
		 * return gson.toJson(EmployeeStore.getInstance().getAllEmployees());
		 */
	}

	@POST
	@Path("add")
	@Consumes(MediaType.APPLICATION_JSON)
	public void addEmployee(Employee employee) {
		EmployeeStore.getInstance().addEmployee(employee);
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("count")
	public int getEmployeeCount() {
		return EmployeeStore.getInstance().getEmployeeCount();
	}

	@DELETE
	@Path("{empNo}")
	@Produces(MediaType.TEXT_PLAIN)
	public String deleteEmployee(@PathParam("empNo") int empNo) {
		logger.debug("Entered the delete employee method");
		return EmployeeStore.getInstance().deleteEmployee(empNo);
	}

	@GET
	@Path("{empNo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Employee getEmployee(@PathParam("empNo") int empNo) {
		logger.debug("Entered the get employee method");
		return EmployeeStore.getInstance().findEmployeeByEmpNo(empNo);

	}

	@GET
	@Path("reset")
	@Produces(MediaType.TEXT_PLAIN)
	public String reset() {
		List<Employee> employees = EmployeeStore.getInstance().resetEmployeeList();
		if (employees == null) {
			return "Could not reset employee list";
		}
		return "Employee List reset";

	}

}
