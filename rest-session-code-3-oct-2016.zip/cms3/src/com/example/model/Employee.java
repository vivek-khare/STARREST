package com.example.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.example.adapter.DateAdapter;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

//import com.google.gson.annotations.SerializedName;

@XmlRootElement
@ApiModel( value = "Employee", description = "Employee resource representation" )
public class Employee {
	//@SerializedName("emp-number")
	@XmlElement(name = "emp-number")
	@ApiModelProperty( value = "Employee number", required = true )
	private int empNo;
	
	@XmlElement(name = "first-name")
	@ApiModelProperty( value = "Employee First Name", required = true )
	private String firstName;
	
	@XmlElement(name = "last-name")
	@ApiModelProperty( value = "Employee Last Name", required = true )
	private String lastName;
	
	@XmlElement(name = "unit-name")
	@ApiModelProperty( value = "Employee Unit Name", required = true )
	private String unitName;
	
	@XmlElement(name = "join-date")
	@XmlJavaTypeAdapter(DateAdapter.class)
	@ApiModelProperty( value = "Employee Join Date", required = true )
	private Date joinDate;
	
	@XmlElement(name = "years-of-experience")
	@ApiModelProperty( value = "Employee Years of Experience", required = true )
	private double yearsOfExperience;
	
	@XmlElement(name = "location")
	@ApiModelProperty( value = "Employee Location", required = true )
	private String location;

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public double getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(double yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
